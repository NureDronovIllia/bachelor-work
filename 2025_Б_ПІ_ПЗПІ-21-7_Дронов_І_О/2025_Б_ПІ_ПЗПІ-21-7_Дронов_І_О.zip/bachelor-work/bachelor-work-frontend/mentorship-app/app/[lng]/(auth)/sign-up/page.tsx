import SignUpForm from './form';

export default async function SignUpPage() {
  return <SignUpForm />;
}
