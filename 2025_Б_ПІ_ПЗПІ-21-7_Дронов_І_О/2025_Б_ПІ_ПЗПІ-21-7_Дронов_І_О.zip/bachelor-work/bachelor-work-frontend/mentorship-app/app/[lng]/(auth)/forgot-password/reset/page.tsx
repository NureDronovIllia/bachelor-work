import ResetPasswordForm from './form';

const ResetPasswordPage = () => {
  return (
    <div>
      <ResetPasswordForm />
    </div>
  );
};

export default ResetPasswordPage;
