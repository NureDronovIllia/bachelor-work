import ForgotPasswordForm from './form';

export default function ForgotPasswordPage() {
  return <ForgotPasswordForm />;
}
