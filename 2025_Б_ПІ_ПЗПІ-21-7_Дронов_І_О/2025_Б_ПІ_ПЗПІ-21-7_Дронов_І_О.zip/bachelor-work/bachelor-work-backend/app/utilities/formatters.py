def error_wrapper(message: str, field: str) -> dict:
    return {"message": message, "field": field}
