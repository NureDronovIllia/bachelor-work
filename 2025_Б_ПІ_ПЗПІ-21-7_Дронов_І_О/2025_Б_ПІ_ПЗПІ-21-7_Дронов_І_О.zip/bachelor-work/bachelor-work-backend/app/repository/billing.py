from app.repository.base import BaseRepository


class BillingRepository(BaseRepository):
    pass
